<?php

require_once "src/Minify.php";
require_once "src/CSS.php";
require_once "src/JS.php";
require_once "src/Exception.php";
require_once "src/Exceptions/BasicException.php";
require_once "src/Exceptions/FileImportException.php";
require_once "src/Exceptions/IOException.php";